package com.example.quranoffline

import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream

data class Verse(
    val page: Int,
    val surah: Int,
    val ayah: Int,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val audio: Map<String, String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranApp() {
    val context = LocalContext.current
    var page by remember { mutableIntStateOf(1) }
    var reciter by remember { mutableStateOf("abdulbasit") }
    var status by remember { mutableStateOf("برای شنیدن، روی محدوده یک آیه در صفحه بزنید.") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }

    val reciters = listOf(
        "abdulbasit" to "عبدالباسط",
        "mishary" to "مشاری العفاسی",
        "minshawi" to "منشاوی"
    )

    fun playVerse(verse: Verse) {
        val assetPath = verse.audio[reciter]
        if (assetPath.isNullOrBlank()) {
            status = "فایل صوتی این آیه برای قاری انتخاب‌شده هنوز اضافه نشده است."
            return
        }
        try {
            player?.release()
            val outFile = File(context.cacheDir, "current_verse.mp3")
            context.assets.open(assetPath).use { input ->
                FileOutputStream(outFile).use { output -> input.copyTo(output) }
            }
            player = MediaPlayer().apply {
                setDataSource(outFile.absolutePath)
                setOnCompletionListener { status = "پخش آیه تمام شد." }
                prepare()
                start()
            }
            status = "در حال پخش سوره ${verse.surah}، آیه ${verse.ayah}"
        } catch (e: Exception) {
            status = "فایل صوتی پیدا نشد. مسیر فایل‌ها را طبق راهنما بررسی کنید."
        }
    }

    val verses = remember(page) { loadVerses(context, page) }
    val pageBitmap = remember(page) {
        try {
            context.assets.open("pages/page_%03d.webp".format(page)).use {
                BitmapFactory.decodeStream(it)?.asImageBitmap()
            }
        } catch (_: Exception) { null }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("القرآن الکریم", textAlign = TextAlign.Center) },
                    actions = {
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            TextButton(onClick = { expanded = true }) {
                                Text(reciters.first { it.first == reciter }.second)
                            }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                reciters.forEach { item ->
                                    DropdownMenuItem(
                                        text = { Text(item.second) },
                                        onClick = { reciter = item.first; expanded = false }
                                    )
                                }
                            }
                        }
                    }
                )
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(12.dp)) {
                    Text(status, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { if (page > 1) page-- }) { Text("صفحه قبل") }
                        Text("$page از ۶۰۴")
                        TextButton(onClick = { if (page < 604) page++ }) { Text("صفحه بعد") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        TextButton(onClick = {
                            player?.let {
                                if (it.isPlaying) { it.pause(); status = "پخش متوقف شد." }
                                else { it.start(); status = "پخش ادامه دارد." }
                            }
                        }) { Text("پخش / توقف") }
                        TextButton(onClick = { player?.seekTo(0); player?.start() }) { Text("تکرار") }
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (pageBitmap != null) {
                    // Tap targets are positioned over the page using normalized rectangles from verses.json.
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val w = maxWidth
                        val h = w * 1.414f
                        Image(
                            bitmap = pageBitmap,
                            contentDescription = "صفحه $page قرآن",
                            modifier = Modifier.fillMaxWidth().height(h)
                        )
                        verses.forEach { verse ->
                            Box(
                                Modifier.offset(x = w * verse.left, y = h * verse.top)
                                    .width(w * (verse.right - verse.left))
                                    .height(h * (verse.bottom - verse.top))
                                    .background(Color(0x2233AA66))
                                    .clickable { playVerse(verse) }
                            )
                        }
                    }
                } else {
                    Text("تصویر صفحه $page هنوز در پوشه pages قرار نگرفته است.", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text("برای نمایش صفحات واقعی، فایل‌های مجاز قرآن را طبق README اضافه کنید.", fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose { player?.release() }
    }
}

fun loadVerses(context: android.content.Context, page: Int): List<Verse> {
    return try {
        val raw = context.assets.open("verses.json").bufferedReader().use { it.readText() }
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val obj = array.getJSONObject(i)
            if (obj.getInt("page") != page) return@mapNotNull null
            val audioObj = obj.optJSONObject("audio")
            val audio = mutableMapOf<String, String>()
            if (audioObj != null) {
                audioObj.keys().forEach { key -> audio[key] = audioObj.getString(key) }
            }
            Verse(
                page, obj.getInt("surah"), obj.getInt("ayah"),
                obj.getDouble("left").toFloat(), obj.getDouble("top").toFloat(),
                obj.getDouble("right").toFloat(), obj.getDouble("bottom").toFloat(), audio
            )
        }
    } catch (_: Exception) { emptyList() }
}
